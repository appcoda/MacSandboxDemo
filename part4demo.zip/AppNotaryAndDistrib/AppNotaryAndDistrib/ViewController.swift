//
//  ViewController.swift
//  AppNotaryAndDistrib
//
//  Created by Andrew Jaffee on 5/20/20.
/*
 
 Copyright (c) 2020 Andrew L. Jaffee, microIT Infrastructure, LLC, and
 iosbrain.com.
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in all
 copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 SOFTWARE.
 
*/

import Cocoa

class ViewController: NSViewController {
    
    // MARK: Instance properties
    
    var userSelectedFolderURL: URL?
    
    @IBOutlet weak var pathTextField: NSTextField!
    
    // MARK: ViewController delegate methods
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.pathTextField.stringValue = "..."
    }
    
    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }

    // MARK: User interaction
    
    /**
     We encourage the user to select a folder, like ~/Documents,
     showing their "intent" to grant our app access to that folder.
     That directory is OUTSIDE of this app's sandbox. We do this
     in preparation for allowing us to reach out of our container. What's
     new in this version of the code is BOOKMARKING the selected folder.
    */
    @IBAction func selectFolderBtnClicked(_ sender: Any) {
        
        self.pathTextField.stringValue = "..."
        
        let folderSelectionDialog = NSOpenPanel() // a modal dialog
        
        folderSelectionDialog.prompt = "Select"
        folderSelectionDialog.message = "Please select a folder"
        
        folderSelectionDialog.canChooseFiles = false
        folderSelectionDialog.allowedFileTypes = ["N/A"]
        folderSelectionDialog.allowsOtherFileTypes = false
        
        folderSelectionDialog.allowsMultipleSelection = false
        
        folderSelectionDialog.canChooseDirectories = true

        // open the MODAL folder selection panel/dialog
        let dialogButtonPressed = folderSelectionDialog.runModal()
        
        // if the user pressed the "Select" (affirmative or "OK")
        // button, then they've chosen a folder
        if dialogButtonPressed == NSApplication.ModalResponse.OK {
            
            if folderSelectionDialog.urls.count == 1 {
                
                if let url = folderSelectionDialog.urls.first {
                    
                    // if the user doesn't select anything, then
                    // the URL "file:///" is returned, which we ignore
                    if url.absoluteString != "file:///" {
                        
                        // save the user's selection so that we can
                        // access the folder they specified later
                        self.userSelectedFolderURL = url
                        
                        print("User selected folder: \(url)")
                        self.pathTextField.stringValue = url.absoluteString
                        
                        // STEP 1 - add the entitlement to our target notifying
                        // macOS that we're using security-scoped bookmarks
                        
                        // STEP 2 - create a persistent bookmark for the
                        // folder the user just selected
                        _ = saveBookmarkForSelectedURL()
                        
                    } else {
                        print("User did not select a folder: file:///")
                    }
                    
                } // end if let url = folderSelectionDialog.urls.first {
                
            } else {
                
                print("User did not select a folder")
                
            } // end if folderSelectionDialog.urls.count
            
        } else if dialogButtonPressed == NSApplication.ModalResponse.cancel { // user clicked on "Cancel"
            
            print("User cancelled folder selection panel")
            
        } // end if dialogButtonPressed == NSApplication.ModalResponse.OK

    } // end func selectFolderBtnClicked
    
    @IBAction func selectFullDiskAccessBtnClicked(_ sender: Any) {
        
        // we use an Apple-specific URL to open System Preferences
        let url = URL.init(string: "x-apple.systempreferences:com.apple.preference.security?Privacy_AllFiles")
        // we present System Preferences for "Full Disk Access" to the user
        NSWorkspace.shared.open(url!)

    }
    
    @IBAction func writeToFileBtnClicked(_ sender: Any) {
        
        self.pathTextField.stringValue = "..."

        // STEP 3 - get the permanent folder location the user selected earlier
        if var persistentURL = getPersistentFileURL() {
            
            // STEP 4 - "Explicitly indicate that you want to use the file-system resource whose URL you obtained in step 3. Do this immediately after obtaining the security-scoped URL..."
            _ = persistentURL.startAccessingSecurityScopedResource()
            
            // create the FULLY-QUALIFIED path to the file by
            // appending a file name to the URL (path)
            persistentURL = persistentURL.appendingPathComponent("test.txt", isDirectory: false)
            print("Persistent URL: ", persistentURL)
            
            // STEP 5 - prepare text to write to the file
            let fileText = "This is the text in the file.";
            
            // try writing file to a non-sandboxed folder...
            do {
                try fileText.write(to: persistentURL, atomically: false, encoding: String.Encoding.utf8)
                self.pathTextField.stringValue = persistentURL.absoluteString
            }
            catch let error // ... or find out why write fails
            {
                print(error.localizedDescription)
                // write some code to recover from error
            }
            
            // STEP 6 - "When done using the resource, explicitly indicate that you want to stop using it. Do this as soon as you know that you no longer need access to the resource (typically, after you close it)."
            persistentURL.stopAccessingSecurityScopedResource()
            
        } // end if var persistentURL = ...
            
    } // end func writeToFileBtnClicked
    
    @IBAction func exitBtnPressed(_ sender: Any) {
        NSApplication.shared.terminate(sender)
    }
    
    // MARK: Security-scoped bookmarks

    func getPersistentFileURL() -> URL? {
        
        // STEP 3 - get the permanent folder location the user selected earlier
        // get from UserDefaults
        let userDefaults = UserDefaults.standard
        if let bookmarkData = userDefaults.data(forKey: "PermanentFolderBookmark") {

            do {
                
                // we'll pass this variable by value so it can be set
                // by an SDK method
                var bookmarkDataIsStale = false
                // STEP 3.1 - "When you later need access to a bookmarked resource, resolve its security-scoped bookmark by calling the the URLByResolvingBookmarkData:options:relativeToURL:bookmarkDataIsStale:error: method of the NSURL class"
                let urlForBookmark = try URL(resolvingBookmarkData: bookmarkData, options: .withSecurityScope, relativeTo: nil, bookmarkDataIsStale: &bookmarkDataIsStale)
                
                // STEP 3.2 - a bookmarks might be "stale" because the app hasn't been used
                // in many months, macOS has been upgraded, the app was
                // re-installed, the app's preferences .plist file was deleted, etc.
                if bookmarkDataIsStale {
                    print("The bookmark is outdated and needs to be regenerated.")
                    _ = saveBookmarkForSelectedURL()
                    return nil
                    
                } else {
                    return urlForBookmark
                }
                
            } catch {
                print("Error resolving bookmark:", error)
                return nil
            }
            
        } else { // bookmarkData is nil
            
            print("Error retrieving persistent bookmark data.")
            return nil
            
        } // end if let bookmarkData =
        
    } // end getPersistentFileURL
    
    func saveBookmarkForSelectedURL() -> Bool {
        
        do {
            
            if let selectedURL = self.userSelectedFolderURL {
                
                // STEP 2.1 - create a security-scoped bookmark
                // "Returns bookmark data for the URL, created with specified options and resource values."
                // Return Value: Type: Data - A bookmark for the URL.
                let bookmarkData = try selectedURL.bookmarkData(options: .withSecurityScope, includingResourceValuesForKeys: nil, relativeTo: nil)

                // get an instance of UserDefaults
                let userDefaults = UserDefaults.standard
                
                // STEP 2.2 - store the newly-created bookmark in UserDefaults
                // accessible with a meaningful key; user defaults supports storing
                // and fetching the Data/NSData types
                userDefaults.set(bookmarkData, forKey: "PermanentFolderBookmark")
                
                // creating the bookmark did not throw an error, so return positive
                return true
                
            } else {
                print("ERROR: You cannot bookmark a URL that is nil")
                return false
            }
            
        } catch let error {
            
            print("Could not create a bookmark because: ", error)
            return false

        }
        
    } // end func saveBookmarkForSelectedURL()

} // end ViewController

